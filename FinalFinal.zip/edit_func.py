#Modules imported
from tkinter import*
import os
from tkinter import messagebox

# 

def directory():
    '''This function sets the directory to the defined path.This path 
    is where all your files will be saved.'''
    path=r"C:\Users\Owner\Desktop\Leahs folder"
    os.chdir(path)
directory()

class window(Frame):
    '''This class contains the widgets that allows the user to edit the file saved previously'''

    def __init__(self,master=None):
        #intitialsation of frame
        Frame.__init__(self,master)
        self.master.title("Journal-E : Journal : Edit")
        self.master.geometry("400x300")
        self.master.configure(bg="#42f59b")

        #Diplaying the files in the path for the user to select.
        Label(self.master,text="Select an entry",font="14", width="50", height="1",bg="#42f59b").pack()
        path=r"C:\Users\Owner\Desktop\Leahs folder"
        self.file_names=os.listdir(path)
        self.srch_box=Entry(self.master)
        self.srch_box.pack()
        file_list=Listbox(self.master)
        file_list.pack()
        for i in range(0,len(self.file_names)):
            a=str(i+1)+") "+self.file_names[i]
            file_list.insert(END,a)

        #Edit button binded with "edit_File" function which allows user to edit the selected file.
        Button(self.master,text="Edit File",width=20,command=self.edit_file).pack()


    def edit_file(self):
        '''This function opens the file specified by the user to edit it.If the file is not present then it shows an error '''
        self.file_name=self.srch_box.get()
        if(self.file_name in self.file_names ):
            f=open(self.file_name,"r")
            content=f.read()
            edit_window=Tk()
            t=Text(edit_window)
            t.pack()
            edit_window.title(self.file_name)
            t.insert("end",content)

            #Saves the edited file.
            def save_file():
                F=open(self.file_name,"w+")
                F.write(t.get("1.0",END))
                messagebox.showinfo("Journal","Your entry was saved!")
                Button(edit_window,text="Save",command=save_file).pack()
        else:
            messagebox.showinfo("Journal","Sorry this file doesn't exist :( ")
